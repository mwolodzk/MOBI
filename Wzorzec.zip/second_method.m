clear all;
%Definitions
%function
f=@(x) exp(-2*x)-7*x
%tolerance
tol=1/1000000000;
%endpoints to begin guessing from
x(1)=1/9;
x(2)=2/3;
%counter starts at 2 because we have two initial points
n=2;
%error
err=abs(x(1)-x(2));
while err>tol
    %secant method
    x(n+1)=x(n)-f(x(n))*(x(n)-x(n-1))/(f(x(n))-f(x(n-1)))
    %update error
    err=abs(x(n+1)-x(n));
    %increment column
    n=n+1;
end
zero=fzero(f,.5)
%output error
err