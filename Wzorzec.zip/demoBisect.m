function xm = demoBisect(fun,xl,xp,n)
% demoBisect Znajduje zero funkji u�ywaj?c metody bisekcji
%
% Dane wejsciowe: xl,xp - lewa i prawa granica obszaru w ktorym
% poszukiwany jest pierwiastek,
% n - (opcjonalnie) liczba iteracji;
% domyslnie: n = 15.
%
% Dane wyjsciowe: x - przyblizone polozenie pierwiastka.
if nargin<4, n=15; end % Ustawienie domyslnej liczby iteracji
a = xl; b = xp;
fa =feval(fun,a)% a - a^(1/3) - 2; % Wartosci poczatkowe f(a) i f(b)
fb =feval(fun,b)% b - b^(1/3) - 2;
fprintf(' k a xmid b f(xmid)\n');
for k=1:n
xm = a + 0.5*(b-a); % Poprawne obliczenie srodka przedzialu
fm = feval(fun,xm); % f(x) w srodku przedzialu
fprintf('%3d %12.8f %12.8f %12.8f %12.3e\n',k,a,xm,b,fm);
if sign(fm)==sign(fa) % Zero lezy w przedziale [xm,b], zamiana a
a = xm;
fa = fm;
else % Zero lezy w przedziale [a,xm], zamiana b
b = xm;
fb = fm;
end
end
