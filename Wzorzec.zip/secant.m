function y = secant ( f, x0, x1, TOL, Nmax )
%SECANT uzywa metody siecznych do znalezienia zera rownania nieliniowego
%
% wywolanie funkcji:
% y = secant ( �f�, x0, x1, TOL, Nmax )
% secant ( �f�, x0, x1, TOL, Nmax )
%
% dane wejsciowe:
% f nazwa pliku m-file definiujacego funkcje ktorej
% zero jest poszukiwane
% x0,x1 poczatkowe przyblizenia polozenia zera funkcji
% TOL dokladnosc z jaka ma byc wyznaczone zero
% NMax maksymalna liczba iteracji
%
% dane wyjsciowe:
% y przyblizone polozenie zera funkcji
%
% UWAGA:
% jezeli SECANT jest wywolane bez argumentu wyjsciowego, to
% wyswietlany bedzie numer iteracji, aktualny przedzial poszukiwan
% oraz przyblizona wartosc zera funkcji
%
older = x0; old = x1;
folder = feval(f,older);
for i = 2 : Nmax
fold = feval(f,old);
dx = fold * ( old - older ) / ( fold - folder );
new = old - dx;
if ( nargout == 0 )

disp ( sprintf ( '\t\t %3d \t %.15f \n', i, new ) )
end
if ( abs(dx) < TOL )
if ( nargout == 1 )
y = new;
end
return
else
older = old;
old = new;
folder = fold;
end
end
disp('Osiagnieta maksymalna liczba iteracji')
if ( nargout == 1 ) y = new; end
