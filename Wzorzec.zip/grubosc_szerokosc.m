clear all
close all
format long

lambda=1.3187e-6;
n1=1.8149;
n2=1.8147;
n3=1;
n4=1;
n5=1;
l=0.03;
k0=2*pi/lambda;
st=k0*n1;
kxx=linspace(0,st,200);
kyx=linspace(0,st,200);
kxy=linspace(0,st,200);
kyy=linspace(0,st,200);

%%%% grubosc d %%%%

y2x=sqrt((k0.^2.*((n1.^2)-(n2.^2)))-kxx.^2);
y3x=sqrt((k0.^2.*((n1.^2)-(n3.^2)))-kxx.^2);

y2y=sqrt((k0.^2.*((n1.^2)-(n2.^2)))-kyx.^2);
y3y=sqrt((k0.^2.*((n1.^2)-(n3.^2)))-kyx.^2);

dx1=((atan(((n1.^2).*kxx.*(((n3.^2).*y2x)+(n2.^2).*y3x))./(((n2.^2).*(n3.^2).*(kxx.^2))-(n1.^4).*y2x.*y3x)))+1.*pi)./kxx;
semilogy(kxx,dx1)
hold on
grid on
dx2=((atan(((n1.^2).*kxx.*(((n3.^2).*y2x)+(n2.^2).*y3x))./(((n2.^2).*(n3.^2).*(kxx.^2))-(n1.^4).*y2x.*y3x)))+2.*pi)./kxx;
semilogy(kxx,dx2)

dx3=((atan(((n1.^2).*kxx.*(((n3.^2).*y2x)+(n2.^2).*y3x))./(((n2.^2).*(n3.^2).*(kxx.^2))-(n1.^4).*y2x.*y3x)))+3.*pi)./kxx;
semilogy(kxx,dx3)
dx4=((atan(((n1.^2).*kxx.*(((n3.^2).*y2x)+(n2.^2).*y3x))./(((n2.^2).*(n3.^2).*(kxx.^2))-(n1.^4).*y2x.*y3x)))+4.*pi)./kxx;
semilogy(kxx,dx4)
dx5=((atan(((n1.^2).*kxx.*(((n3.^2).*y2x)+(n2.^2).*y3x))./(((n2.^2).*(n3.^2).*(kxx.^2))-(n1.^4).*y2x.*y3x)))+5.*pi)./kxx;
semilogy(kxx,dx5)
dx6=((atan(((n1.^2).*kxx.*(((n3.^2).*y2x)+(n2.^2).*y3x))./(((n2.^2).*(n3.^2).*(kxx.^2))-(n1.^4).*y2x.*y3x)))+6.*pi)./kxx;
semilogy(kxx,dx6)


dy1=((atan((kyx.*(y2y+y3y))./((kyx.^2)-y2y.*y3y)))+1*pi)./kyx;
semilogy(kyx,dy1)
dy2=((atan((kyx.*(y2y+y3y))./((kyx.^2)-y2y.*y3y)))+2*pi)./kyx;
semilogy(kyx,dy2)

dy3=((atan((kyx.*(y2y+y3y))./((kyx.^2)-y2y.*y3y)))+3*pi)./kyx;
semilogy(kyx,dy3)
dy4=((atan((kyx.*(y2y+y3y))./((kyx.^2)-y2y.*y3y)))+4*pi)./kyx;
semilogy(kyx,dy4)
dy5=((atan((kyx.*(y2y+y3y))./((kyx.^2)-y2y.*y3y)))+5*pi)./kyx;
semilogy(kyx,dy5)
dy6=((atan((kyx.*(y2y+y3y))./((kyx.^2)-y2y.*y3y)))+6*pi)./kyx;
semilogy(kyx,dy6)

legend('dx1','dx2','dx3','dx4','dx5','dx6','dy1','dy2','dy3','dy4','dy5','dy6')
xlabel('kx')
ylabel('d')
title('Grubo�� odci�cia')
hold off

%%%% szeroko�� t %%%%

y4x=sqrt((k0.^2.*((n1.^2)-(n4.^2)))-kxy.^2);
y5x=sqrt((k0.^2.*((n1.^2)-(n5.^2)))-kxy.^2);

y4y=sqrt((k0.^2.*((n1.^2)-(n4.^2)))-kyy.^2);
y5y=sqrt((k0.^2.*((n1.^2)-(n5.^2)))-kyy.^2);

figure()
tx1=((atan((kxy.*(y4x+y5x))./((kxy.^2)-y4x.*y5x)))+1*pi)./kxy;
semilogy(kxy,tx1)
hold on
grid on
tx2=((atan((kxy.*(y4x+y5x))./((kxy.^2)-y4x.*y5x)))+1*pi)./kxy;
semilogy(kxy,tx2)

tx3=((atan((kxy.*(y4x+y5x))./((kxy.^2)-y4x.*y5x)))+3*pi)./kxy;
semilogy(kxy,tx3)
tx4=((atan((kxy.*(y4x+y5x))./((kxy.^2)-y4x.*y5x)))+4*pi)./kxy;
semilogy(kxy,tx4)
tx5=((atan((kxy.*(y4x+y5x))./((kxy.^2)-y4x.*y5x)))+5*pi)./kxy;
semilogy(kxy,tx5)
tx6=((atan((kxy.*(y4x+y5x))./((kxy.^2)-y4x.*y5x)))+6*pi)./kxy;
semilogy(kxy,tx6)


ty1=((atan(((n1.^2).*kyy.*(((n4.^2).*y5y)+(n5.^2).*y4y))./(((n4.^2).*(n5.^2).*(kyy.^2))-(n1.^4).*y4y.*y5y)))+1.*pi)./kxy;
semilogy(kyy,ty1)
ty2=((atan(((n1.^2).*kyy.*(((n4.^2).*y5y)+(n5.^2).*y4y))./(((n4.^2).*(n5.^2).*(kyy.^2))-(n1.^4).*y4y.*y5y)))+2.*pi)./kxy;
semilogy(kyy,ty2)

ty3=((atan(((n1.^2).*kyy.*(((n4.^2).*y5y)+(n5.^2).*y4y))./(((n4.^2).*(n5.^2).*(kyy.^2))-(n1.^4).*y4y.*y5y)))+3.*pi)./kxy;
semilogy(kyy,ty3)
ty4=((atan(((n1.^2).*kyy.*(((n4.^2).*y5y)+(n5.^2).*y4y))./(((n4.^2).*(n5.^2).*(kyy.^2))-(n1.^4).*y4y.*y5y)))+4.*pi)./kxy;
semilogy(kyy,ty4)
ty5=((atan(((n1.^2).*kyy.*(((n4.^2).*y5y)+(n5.^2).*y4y))./(((n4.^2).*(n5.^2).*(kyy.^2))-(n1.^4).*y4y.*y5y)))+5.*pi)./kxy;
plot(kyy,ty5)
ty6=((atan(((n1.^2).*kyy.*(((n4.^2).*y5y)+(n5.^2).*y4y))./(((n4.^2).*(n5.^2).*(kyy.^2))-(n1.^4).*y4y.*y5y)))+6.*pi)./kxy;
semilogy(kyy,ty6)

legend('tx1','tx2','tx3','tx4','tx5','tx6','ty1','ty2','ty3','ty4','ty5','ty6')
xlabel('ky')
ylabel('t')
title('Szeroko�� odci�cia')
hold off

kkxxm=[6.085e6, 6.5e6, 6.9e6, 7.35e6, 7.7e6];
kkyxm=[5.495e6, 6.292e6, 6.860e6, 7.087e6, 7.480e6];
kkyyn=[3.932e6, 5.164e6, 6e6, 6.396e6, 6.45e6];
kkxyn=[3.192e6, 4.5e6, 5.5e6, 6.1e6, 6.2e6];


Bx=sqrt(((n1.^2).*(k0.^2))-(kkxxm(1).^2)-(kkxyn(5).^2))
By=sqrt(((n1.^2).*(k0.^2))-(kkyxm(1).^2)-(kkyyn(5).^2))

