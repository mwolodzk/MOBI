function y = funxx(kxx)

lambda=1.3187e-6;
n1=1.8149;
n2=1.8147;
n3=1;
n4=1;
n5=1;
l=0.03;
k0=2*pi/lambda;
st=k0*n1;

y2x=sqrt((k0.^2.*((n1.^2)-(n2.^2)))-kxx.^2);
y3x=sqrt((k0.^2.*((n1.^2)-(n3.^2)))-kxx.^2);


y=(((atan(((n1.^2).*kxx.*(((n3.^2).*y2x)+(n2.^2).*y3x))./(((n2.^2).*(n3.^2).*(kxx.^2))-(n1.^4).*y2x.*y3x)))+1.*pi)./kxx)-(7e-7)

end