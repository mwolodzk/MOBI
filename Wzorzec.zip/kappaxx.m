clear all
close all
format long

global n1
global n3
global n2
global k0
 
%grubosc odciecia dla modu Ex11 i Ey11
dx1 = 0.6969e-6;

%dokladnosc
dokladnosc = 1e-14;

kxx(1) = 1.747e+5;
kxx(2) = 6.114e+6;
kxx0 = (kxx(1) + kxx(2))./2;

%licznik zaczyna sie od 2, poniewaz mamy dwa poczatkowe punkty
i = 2;

y2x=sqrt((k0.^2.*(n1.^2-n2.^2))-kxx(i).^2);
y3x=sqrt((k0.^2.*(n1.^2-n3.^2))-kxx(1).^2);

%funckja do wyznaczenia kappyxx1
f=@(kxx)(atan(((n1.^2).*kxx.*(((n3.^2).*y2x)+(n2.^2).*y3x))./(((n2.^2).*(n3.^2).*(kxx.^2))-(n1.^4).*y2x.*y3x)))+1.*pi - dx1.*kxx;

%error
err = abs(kxx(1) - kxx(2));

while err>dokladnosc
    %metoda siecznych
    kxx(i+1)=kxx(i)-f(kxx(i)).*(kxx(i)-kxx(i-1))./(f(kxx(i))-f(kxx(i-1)));
    err = abs(kxx(i+1) - kxx(i));
    i = i+1;
end

zero = fzero(f, kxx0);
err